import { Flame, Loader2, Search, Shuffle, Star, Rows3 } from "lucide-react";
import {
  CATEGORIES,
  DAY_MS,
  MOODS,
  isAlive,
  isSealed,
  moodInfo,
  type Confession,
  type Theme,
} from "@/lib/whisper";
import { ConfessionCard } from "./ConfessionCard";

function MoodWeather({ t, confessions, now }: { t: Theme; confessions: Confession[]; now: number }) {
  const recent = confessions.filter(
    (c) => isAlive(c, now) && now - new Date(c.created_at).getTime() <= DAY_MS,
  );
  const withMood = recent.filter((c) => c.mood);
  if (withMood.length === 0) return null;

  const counts: Record<string, number> = {};
  withMood.forEach((c) => {
    counts[c.mood as string] = (counts[c.mood as string] || 0) + 1;
  });
  const breakdown = MOODS.map((m) => ({
    ...m,
    pct: ((counts[m.key] || 0) / withMood.length) * 100,
  })).filter((m) => m.pct > 0);
  const top = [...breakdown]
    .sort((a, b) => b.pct - a.pct)
    .slice(0, 2)
    .map((m) => m.label.toLowerCase());

  return (
    <div className="fade-in mb-6">
      <div className="mb-1.5">
        <span className="whisper-sans text-xs" style={{ color: t.textDim }}>
          The wall feels mostly <span style={{ color: t.accentText }}>{top.join(" and ")}</span> tonight
        </span>
      </div>
      <div className="flex h-1.5 overflow-hidden rounded-full" style={{ background: t.borderStrong }}>
        {breakdown.map((m) => (
          <div key={m.key} style={{ width: `${m.pct}%`, background: m.color }} title={m.label} />
        ))}
      </div>
    </div>
  );
}

function hashPos(id: string) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  const x = (h % 9000) / 100 + 4;
  const y = ((h >>> 8) % 7500) / 100 + 6;
  return { x: Math.min(x, 94), y: Math.min(y, 80) };
}

function SkyView({
  t,
  visible,
  now,
  onOpen,
}: {
  t: Theme;
  visible: Confession[];
  now: number;
  onOpen: (c: Confession) => void;
}) {
  return (
    <div
      className="fade-in relative overflow-hidden rounded-2xl"
      style={{
        height: 420,
        background: t.panelAlt,
        backdropFilter: t.blur,
        border: `1px solid ${t.border}`,
      }}
    >
      {visible.map((c) => {
        const md = moodInfo(c.mood);
        const color = md?.color || t.accent;
        const { x, y } = hashPos(c.id);
        const size = Math.max(9, Math.min(22, 9 + c.candle_count * 1.6));
        const sealed = isSealed(c, now);
        return (
          <button
            key={c.id}
            onClick={() => onOpen(c)}
            aria-label={sealed ? "A sealed whisper" : c.content.slice(0, 60)}
            title={sealed ? "A sealed whisper" : c.content.slice(0, 60)}
            className="whisper-btn flame-flicker absolute rounded-full"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              width: size,
              height: size,
              background: sealed ? t.textFaint : color,
              boxShadow: sealed ? "none" : `0 0 ${size}px ${color}`,
              opacity: sealed ? 0.45 : 0.9,
              animationDuration: `${2 + (size % 3)}s`,
            }}
          />
        );
      })}
      <span className="whisper-mono absolute bottom-3 right-4 text-[10px]" style={{ color: t.textFaint }}>
        tap a light to read it
      </span>
    </div>
  );
}

export function FeedView({
  t,
  loading,
  visible,
  confessions,
  search,
  setSearch,
  activeCat,
  setActiveCat,
  sortBy,
  setSortBy,
  litIds,
  onLight,
  openReplies,
  toggleReplies,
  replyDrafts,
  setReplyDraft,
  onReply,
  now,
  onShuffle,
  goConfess,
  layout,
  setLayout,
  onOpenSpotlight,
}: {
  t: Theme;
  loading: boolean;
  visible: Confession[];
  confessions: Confession[];
  search: string;
  setSearch: (v: string) => void;
  activeCat: string;
  setActiveCat: (v: string) => void;
  sortBy: string;
  setSortBy: (v: string) => void;
  litIds: Set<string>;
  onLight: (id: string) => void;
  openReplies: Set<string>;
  toggleReplies: (id: string) => void;
  replyDrafts: Record<string, string>;
  setReplyDraft: (id: string, v: string) => void;
  onReply: (id: string) => void;
  now: number;
  onShuffle: () => void;
  goConfess: () => void;
  layout: "list" | "sky";
  setLayout: (v: "list" | "sky") => void;
  onOpenSpotlight: (c: Confession) => void;
}) {
  if (loading) {
    return (
      <div className="whisper-sans flex flex-col items-center justify-center py-24 text-sm" style={{ color: t.textDim }}>
        <Loader2 className="mb-3 animate-spin" size={20} />
        Lighting the candles...
      </div>
    );
  }

  const control = {
    background: t.panel,
    backdropFilter: t.blur,
    border: `1px solid ${t.border}`,
    color: t.text,
  };

  return (
    <div className="fade-in">
      <MoodWeather t={t} confessions={confessions} now={now} />

      <div className="mb-5 flex flex-col gap-3 sm:flex-row">
        <div className="flex min-h-11 flex-1 items-center gap-2 rounded-xl px-4 py-2" style={control}>
          <Search size={15} style={{ color: t.textFaint }} className="shrink-0" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search whispers"
            className="whisper-sans w-full min-w-0 bg-transparent text-sm outline-none"
            style={{ color: t.text }}
          />
        </div>
        <div className="flex gap-2">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            aria-label="Sort whispers"
            className="whisper-sans min-h-11 flex-1 rounded-xl px-3 text-sm outline-none sm:flex-none"
            style={control}
          >
            <option value="new">Newest</option>
            <option value="candles">Most resonated</option>
          </select>
          <button
            onClick={onShuffle}
            title="Draw a random whisper"
            aria-label="Draw a random whisper"
            className="whisper-btn flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
            style={{ ...control, color: t.textDim }}
          >
            <Shuffle size={15} />
          </button>
          <button
            onClick={() => setLayout(layout === "list" ? "sky" : "list")}
            title={layout === "list" ? "View as a constellation" : "View as a list"}
            aria-label={layout === "list" ? "View as a constellation" : "View as a list"}
            className="whisper-btn flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
            style={{
              ...control,
              background: layout === "sky" ? t.accentSoft : t.panel,
              color: layout === "sky" ? t.accentText : t.textDim,
            }}
          >
            {layout === "list" ? <Star size={15} /> : <Rows3 size={15} />}
          </button>
        </div>
      </div>

      <div className="no-scrollbar mb-6 flex gap-2 overflow-x-auto pb-1">
        {[{ key: "all", label: "All" }, ...CATEGORIES].map((c) => {
          const active = activeCat === c.key;
          return (
            <button
              key={c.key}
              onClick={() => setActiveCat(c.key)}
              className="whisper-btn whisper-sans min-h-11 whitespace-nowrap rounded-full px-3 text-sm"
              style={{
                background: active ? t.accentSoft : t.panel,
                backdropFilter: t.blur,
                border: `1px solid ${active ? t.accent : t.border}`,
                color: active ? t.accentText : t.textDim,
              }}
            >
              {c.label}
            </button>
          );
        })}
      </div>

      {visible.length === 0 ? (
        <div className="py-20 text-center">
          <Flame className="flame-flicker mx-auto mb-3" size={22} style={{ color: t.accent }} />
          <p className="whisper-serif mb-3 text-xl italic" style={{ color: t.textDim }}>
            {confessions.length === 0 ? "The wall is empty." : "No whispers match."}
          </p>
          {confessions.length === 0 && (
            <button onClick={goConfess} className="whisper-sans text-sm underline" style={{ color: t.accentText }}>
              be the first
            </button>
          )}
        </div>
      ) : layout === "sky" ? (
        <SkyView t={t} visible={visible} now={now} onOpen={onOpenSpotlight} />
      ) : (
        <div className="columns-1 gap-4 md:columns-2">
          {visible.map((c, idx) => (
            <div
              key={c.id}
              className="fade-in mb-4 break-inside-avoid"
              style={{ animationDelay: `${Math.min(idx, 8) * 40}ms` }}
            >
              <ConfessionCard
                t={t}
                c={c}
                lit={litIds.has(c.id)}
                onLight={() => onLight(c.id)}
                repliesOpen={openReplies.has(c.id)}
                onToggleReplies={() => toggleReplies(c.id)}
                draft={replyDrafts[c.id] || ""}
                setDraft={(v) => setReplyDraft(c.id, v)}
                onReply={() => onReply(c.id)}
                now={now}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
