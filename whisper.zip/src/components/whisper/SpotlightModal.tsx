import { X } from "lucide-react";
import { catInfo, moodInfo, timeAgo, type Confession, type Theme } from "@/lib/whisper";
import { CandleButton } from "./ConfessionCard";

export function SpotlightModal({
  t,
  confession,
  onClose,
  lit,
  onLight,
  now,
}: {
  t: Theme;
  confession: Confession;
  onClose: () => void;
  lit: boolean;
  onLight: () => void;
  now: number;
}) {
  const cat = catInfo(confession.category);
  const md = moodInfo(confession.mood);
  const Icon = cat.icon;
  const sealed = !!confession.seal_until && new Date(confession.seal_until).getTime() > now;

  return (
    <div
      className="fade-in fixed inset-0 z-50 flex items-center justify-center p-5"
      style={{ background: t.modalBg, backdropFilter: "blur(6px)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-2xl p-6"
        style={{ background: t.panelAlt, backdropFilter: t.blur, border: `1px solid ${t.borderStrong}` }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <span className="whisper-sans flex min-w-0 items-center gap-1.5 text-xs" style={{ color: t.textDim }}>
            <Icon size={13} className="shrink-0" />
            <span className="truncate">
              {cat.label}
              {md && <span style={{ color: md.color }}> · {md.label}</span>}
            </span>
          </span>
          <button
            onClick={onClose}
            aria-label="Close"
            className="whisper-btn flex h-9 w-9 shrink-0 items-center justify-center rounded-full"
            style={{ border: `1px solid ${t.border}`, color: t.textDim }}
          >
            <X size={15} />
          </button>
        </div>

        {sealed ? (
          <p className="whisper-serif text-lg italic" style={{ color: t.textDim }}>
            This one is still sealed. Come back later.
          </p>
        ) : (
          <>
            {confession.to_whom && (
              <p className="whisper-sans mb-2 text-xs italic" style={{ color: t.textDim }}>
                to {confession.to_whom}
              </p>
            )}
            <p
              className="whisper-serif whitespace-pre-wrap break-words text-xl leading-relaxed"
              style={{ color: t.text }}
            >
              {confession.content}
            </p>
          </>
        )}

        <div className="mt-6 flex items-center justify-between">
          <CandleButton
            t={t}
            lit={lit}
            count={confession.candle_count}
            onLight={onLight}
            label="light a candle"
          />
          <span className="whisper-mono text-xs" style={{ color: t.textFaint }}>
            {timeAgo(confession.created_at, now)}
          </span>
        </div>
      </div>
    </div>
  );
}
