import { supabase } from "@/integrations/supabase/client";
import type { Confession, Reply } from "./whisper";

const DEVICE_KEY = "whisper-device-id";
const LIT_KEY = "whisper-lit";

export function getDeviceId(): string {
  if (typeof window === "undefined") return "server0000";
  let id = localStorage.getItem(DEVICE_KEY);
  if (!id) {
    id = "d" + Date.now().toString(36) + Math.random().toString(36).slice(2, 12);
    localStorage.setItem(DEVICE_KEY, id);
  }
  return id;
}

export function getLitIds(): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    return new Set(JSON.parse(localStorage.getItem(LIT_KEY) || "[]") as string[]);
  } catch {
    return new Set();
  }
}

export function saveLitIds(ids: Set<string>) {
  localStorage.setItem(LIT_KEY, JSON.stringify([...ids]));
}

function normalize(row: Record<string, unknown>): Confession {
  return {
    ...(row as unknown as Confession),
    replies: Array.isArray(row.replies) ? (row.replies as Reply[]) : [],
  };
}

export async function fetchConfessions(): Promise<Confession[]> {
  const { data, error } = await supabase
    .from("confessions")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(300);
  if (error) throw error;
  return (data || []).map(normalize);
}

export async function createConfession(input: {
  category: string;
  to_whom: string | null;
  mood: string | null;
  content: string;
  expires_at: string | null;
  seal_until: string | null;
}): Promise<Confession> {
  const { data, error } = await supabase.from("confessions").insert(input).select().single();
  if (error) throw error;
  return normalize(data);
}

export async function lightCandleRpc(confessionId: string): Promise<number> {
  const { data, error } = await supabase.rpc("light_candle", {
    _confession_id: confessionId,
    _device_id: getDeviceId(),
  });
  if (error) throw error;
  return data as number;
}

export async function addReplyRpc(confessionId: string, text: string): Promise<Reply[]> {
  const { data, error } = await supabase.rpc("add_reply", {
    _confession_id: confessionId,
    _text: text,
  });
  if (error) throw error;
  return (data as Reply[]) || [];
}
