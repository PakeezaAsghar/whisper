import {
  Heart,
  Home,
  Users,
  Briefcase,
  CloudRain,
  Ghost,
  Sparkles,
  HelpCircle,
  Smile,
  type LucideIcon,
} from "lucide-react";

export const DAY_MS = 86400000;

export type Reply = { id: string; text: string; created_at: string };

export type Confession = {
  id: string;
  category: string;
  to_whom: string | null;
  mood: string | null;
  content: string;
  created_at: string;
  expires_at: string | null;
  seal_until: string | null;
  candle_count: number;
  replies: Reply[];
};

export const CATEGORIES: { key: string; label: string; icon: LucideIcon }[] = [
  { key: "love", label: "Love", icon: Heart },
  { key: "crush", label: "Crush", icon: Smile },
  { key: "family", label: "Family", icon: Home },
  { key: "friendship", label: "Friendship", icon: Users },
  { key: "work", label: "Work", icon: Briefcase },
  { key: "regret", label: "Regret", icon: CloudRain },
  { key: "fear", label: "Fear", icon: Ghost },
  { key: "dream", label: "Dream", icon: Sparkles },
  { key: "other", label: "Other", icon: HelpCircle },
];

export const MOODS = [
  { key: "calm", label: "Calm", color: "#6C8EBF" },
  { key: "tender", label: "Tender", color: "#C97064" },
  { key: "heavy", label: "Heavy", color: "#7C5C8C" },
  { key: "hopeful", label: "Hopeful", color: "#D9A24B" },
  { key: "lonely", label: "Lonely", color: "#5B6E8C" },
  { key: "numb", label: "Numb", color: "#6B6B7A" },
];

export type Mode = "night" | "day";

export type Theme = {
  bg: string;
  bgGradient: string;
  panel: string;
  panelAlt: string;
  border: string;
  borderStrong: string;
  text: string;
  textDim: string;
  textFaint: string;
  accent: string;
  accentText: string;
  accentSoft: string;
  ink: string;
  particle: string;
  particleOpacity: [number, number];
  danger: string;
  dangerBg: string;
  dangerBorder: string;
  modalBg: string;
  blur: string;
  wordmark: string;
};

export const THEMES: Record<Mode, Theme> = {
  night: {
    bg: "#0B0E1A",
    bgGradient:
      "radial-gradient(ellipse at 50% -10%, rgba(124,92,140,0.28), transparent 60%), radial-gradient(ellipse at 20% 110%, rgba(232,184,109,0.14), transparent 55%)",
    panel: "rgba(20,24,48,0.6)",
    panelAlt: "rgba(26,31,59,0.65)",
    border: "rgba(232,184,109,0.14)",
    borderStrong: "rgba(232,184,109,0.28)",
    text: "#F2ECE1",
    textDim: "#9997B3",
    textFaint: "#6E6C86",
    accent: "#E8B86D",
    accentText: "#E8B86D",
    accentSoft: "rgba(232,184,109,0.15)",
    ink: "#0B0E1A",
    particle: "#E8B86D",
    particleOpacity: [0.1, 0.3],
    danger: "#E8A0A0",
    dangerBg: "rgba(163,75,75,0.15)",
    dangerBorder: "rgba(163,75,75,0.4)",
    modalBg: "rgba(8,10,18,0.88)",
    blur: "blur(16px)",
    wordmark: "#FFFFFF",
  },
  day: {
    bg: "#F7F1E6",
    bgGradient:
      "radial-gradient(ellipse at 50% -10%, rgba(255,224,180,0.55), transparent 60%), radial-gradient(ellipse at 20% 110%, rgba(201,133,46,0.12), transparent 55%)",
    panel: "rgba(255,252,245,0.62)",
    panelAlt: "rgba(251,243,228,0.68)",
    border: "rgba(120,80,30,0.16)",
    borderStrong: "rgba(120,80,30,0.32)",
    text: "#2B2620",
    textDim: "#847A69",
    textFaint: "#A69C89",
    accent: "#C9852E",
    accentText: "#A9691E",
    accentSoft: "rgba(201,133,46,0.14)",
    ink: "#FFFCF5",
    particle: "#C9852E",
    particleOpacity: [0.08, 0.22],
    danger: "#A34B4B",
    dangerBg: "rgba(163,75,75,0.08)",
    dangerBorder: "rgba(163,75,75,0.3)",
    modalBg: "rgba(247,241,230,0.9)",
    blur: "blur(16px)",
    wordmark: "#17140F",
  },
};

export function catInfo(key: string) {
  return CATEGORIES.find((c) => c.key === key) || CATEGORIES[CATEGORIES.length - 1];
}

export function moodInfo(key: string | null) {
  if (!key) return null;
  return MOODS.find((m) => m.key === key) || null;
}

export function timeAgo(iso: string, now: number) {
  const ts = new Date(iso).getTime();
  const s = Math.max(0, Math.floor((now - ts) / 1000));
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

export function initialMode(): Mode {
  if (typeof window === "undefined") return "night";
  const h = new Date().getHours();
  return h >= 6 && h < 18 ? "day" : "night";
}

export function isSealed(c: Confession, now: number) {
  return !!c.seal_until && new Date(c.seal_until).getTime() > now;
}

export function isAlive(c: Confession, now: number) {
  return !c.expires_at || new Date(c.expires_at).getTime() > now;
}
