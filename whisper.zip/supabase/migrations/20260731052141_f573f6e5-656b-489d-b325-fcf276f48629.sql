CREATE TABLE public.confessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL DEFAULT 'other',
  to_whom text,
  mood text,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  seal_until timestamptz,
  candle_count integer NOT NULL DEFAULT 0,
  replies jsonb NOT NULL DEFAULT '[]'::jsonb
);

CREATE INDEX confessions_created_at_idx ON public.confessions (created_at DESC);

CREATE TABLE public.candle_lights (
  confession_id uuid NOT NULL REFERENCES public.confessions(id) ON DELETE CASCADE,
  device_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (confession_id, device_id)
);

GRANT SELECT, INSERT ON public.confessions TO anon, authenticated;
GRANT ALL ON public.confessions TO service_role;
GRANT SELECT, INSERT ON public.candle_lights TO anon, authenticated;
GRANT ALL ON public.candle_lights TO service_role;

ALTER TABLE public.confessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.candle_lights ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read confessions" ON public.confessions FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can post a confession" ON public.confessions FOR INSERT TO anon, authenticated
  WITH CHECK (
    char_length(content) BETWEEN 1 AND 1000
    AND (to_whom IS NULL OR char_length(to_whom) <= 60)
    AND candle_count = 0
    AND replies = '[]'::jsonb
  );

CREATE POLICY "Anyone can read candle lights" ON public.candle_lights FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can light a candle" ON public.candle_lights FOR INSERT TO anon, authenticated
  WITH CHECK (char_length(device_id) BETWEEN 6 AND 64);

CREATE OR REPLACE FUNCTION public.light_candle(_confession_id uuid, _device_id text)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _count integer;
BEGIN
  IF char_length(_device_id) < 6 OR char_length(_device_id) > 64 THEN
    RAISE EXCEPTION 'invalid device id';
  END IF;

  INSERT INTO public.candle_lights (confession_id, device_id)
  VALUES (_confession_id, _device_id)
  ON CONFLICT DO NOTHING;

  IF NOT FOUND THEN
    SELECT candle_count INTO _count FROM public.confessions WHERE id = _confession_id;
    RETURN _count;
  END IF;

  UPDATE public.confessions
     SET candle_count = candle_count + 1
   WHERE id = _confession_id
  RETURNING candle_count INTO _count;

  RETURN _count;
END;
$$;

CREATE OR REPLACE FUNCTION public.add_reply(_confession_id uuid, _text text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _replies jsonb;
  _clean text := btrim(_text);
BEGIN
  IF char_length(_clean) < 1 OR char_length(_clean) > 300 THEN
    RAISE EXCEPTION 'reply must be 1-300 characters';
  END IF;

  UPDATE public.confessions
     SET replies = replies || jsonb_build_object(
       'id', gen_random_uuid(),
       'text', _clean,
       'created_at', now()
     )
   WHERE id = _confession_id
     AND jsonb_array_length(replies) < 200
  RETURNING replies INTO _replies;

  RETURN COALESCE(_replies, '[]'::jsonb);
END;
$$;

GRANT EXECUTE ON FUNCTION public.light_candle(uuid, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.add_reply(uuid, text) TO anon, authenticated;